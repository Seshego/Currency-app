import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;


public class model {

    private static HttpURLConnection connection;

    public static void main(String[] args) throws MalformedURLException {

        BufferedReader reader;
        String line;
        StringBuffer responseContent = new StringBuffer();
         DecimalFormat df = new DecimalFormat("0.00");

        try {
            URL url = new URL("https://freecurrencyapi.net/api/v2/latest?apikey=f2e8d590-5845-11ec-8b95-5358a4e7af08");
            connection = (HttpURLConnection) url.openConnection();

            //request setup
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type", "application/json");
            //setting up the brower.
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36");

            //Test Connection and display
            int status = connection.getResponseCode();
           // System.out.println(status);

            //Reading the json file

            if(status >299) {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                while ((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }
                reader.close();

            }else {
              reader = new BufferedReader(new InputStreamReader( connection.getInputStream()));
              while(( line = reader.readLine()) !=null )
              {
                  responseContent.append(line);
              }
                reader.close();
            }
            //Displaying the json content
       // System.out.println(responseContent.toString());
            JSONObject currObj = new JSONObject(responseContent.toString());
         //System.out.println(currObj);
            // System.out.println("Data: "+ currObj.getString("data"));

            JSONObject rateObj = new JSONObject (currObj.getJSONObject("data").toString());

            System.out.println("USD to ZAR: R"+df.format(rateObj.getDouble("ZAR") ));
         System.out.println("USD to BDT: ৲"+ df.format(rateObj.getDouble("BDT")));
         System.out.println("USD to PKR: Rs"+ df.format(rateObj.getDouble("PKR")));
         System.out.println("USD to INR: ₹"+ df.format(rateObj.getDouble("INR")));



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }

    }

}
